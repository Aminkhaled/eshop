<?php
include "../vendor/autoload.php";
include "core/config.php";
include "core/controller.php";
include "core/database.php";
include "core/functions.php";
include "core/app.php";

