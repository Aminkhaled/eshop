<?php
class Products{
    public function index(){
        echo "this is Products";
    }
}