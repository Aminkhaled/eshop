


<script src="<?php echo ASSETS ?>eshop/js/jquery.js"></script>
<script src="<?php echo ASSETS ?>eshop/js/bootstrap.min.js"></script>
<script src="<?php echo ASSETS ?>eshop/js/jquery.scrollUp.min.js"></script>
<script src="<?php echo ASSETS ?>eshop/js/price-range.js"></script>
<script src="<?php echo ASSETS ?>eshop/js/jquery.prettyPhoto.js"></script>
<script src="<?php echo ASSETS ?>eshop/js/main.js"></script>
<script>
    var text_to_copy = document.getElementById("vcard-text").innerHTML;

    function vcard_copy(){
        navigator.clipboard.writeText(text_to_copy);
    }

</script>
</body>
</html>